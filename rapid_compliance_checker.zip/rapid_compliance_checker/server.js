const express = require("express");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const connectDB = require("./db");
const Parcel = require("./models/Parcel.js");

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // Enable form data parsing
app.use(cors());

// Connect to MongoDB
connectDB();

// Multer setup for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads/");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });

// Serve Static Files
app.use(express.static("public"));

// ✅ **POST /add-parcel**
app.post("/add-parcel", upload.single("customsDeclaration"), async (req, res) => {
    try {
        console.log("req recieved ")
        console.log("Received form data:", req.body);  // Debugging log
        console.log("Received file:", req.file);  // Check if file is uploaded

        const newParcel = new Parcel({
            senderName: req.body.senderName,
            senderAddress: req.body.senderAddress,
            senderContact: req.body.senderContact,
            senderEmail: req.body.senderEmail,
            receiverName: req.body.receiverName,
            receiverAddress: req.body.receiverAddress,
            receiverContact: req.body.receiverContact,
            receiverEmail: req.body.receiverEmail,
            itemType: req.body.itemType,
            quantity: req.body.quantity,
            weight: req.body.weight,
            value: req.body.value,
            destination: req.body.destination,
            customsDeclaration: req.file ? req.file.filename : null
        });

        await newParcel.save();
        res.status(201).json({ success: true, message: "Parcel data inserted successfully.", parcel: newParcel });
    } catch (error) {
        console.error("Error inserting parcel data:", error);  // Logs error in terminal
        res.status(500).json({ success: false, message: "Error inserting parcel data.", error: error.message });
    }
});


// Start Server
const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
