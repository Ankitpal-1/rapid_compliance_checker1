document.addEventListener("DOMContentLoaded", function () {
  const parcelForm = document.getElementById("parcelForm");
  const feedback = document.getElementById("feedback");

  parcelForm.addEventListener("submit", async function (event) {
      event.preventDefault();

      // Collect form data
      const formData = new FormData();
      formData.append("senderName", document.getElementById("senderName").value);
      formData.append("senderAddress", document.getElementById("senderAddress").value);
      formData.append("senderContact", document.getElementById("senderContact").value);
      formData.append("senderEmail", document.getElementById("senderEmail").value);
      formData.append("receiverName", document.getElementById("receiverName").value);
      formData.append("receiverAddress", document.getElementById("receiverAddress").value);
      formData.append("receiverContact", document.getElementById("receiverContact").value);
      formData.append("receiverEmail", document.getElementById("receiverEmail").value);
      formData.append("itemType", document.getElementById("itemType").value);
      formData.append("quantity", document.getElementById("quantity").value);
      formData.append("weight", document.getElementById("weight").value);
      formData.append("value", document.getElementById("value").value);
      formData.append("destination", document.getElementById("destination").value);
      formData.append("customsDeclaration", document.getElementById("customsDeclaration").files[0]);

      try {
          const response = await fetch("http://localhost:5000/add-parcel", {
              method: "POST",
              body: formData
          });

          console.log(response)

          const result = await response.json();

          if (result.success) {
              feedback.innerHTML = `<p style="color: green;">${result.message}</p>`;
              parcelForm.reset();
          } else {
              feedback.innerHTML = `<p style="color: red;">${result.message}</p>`;
          }
      } catch (error) {
          feedback.innerHTML = `<p style="color: red;">Error submitting form: ${error.message}</p>`;
      }
  });
});
