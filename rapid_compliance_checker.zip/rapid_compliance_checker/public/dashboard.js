// 🚀 Sidebar Navigation
function showTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.style.display = 'none');
    document.getElementById(tabId).style.display = 'block';
}

// 🚀 Parcel Tracking System
function processParcel() {
    let parcelID = document.getElementById("parcelID").value;
    if (!parcelID) {
        alert("Please enter a Parcel ID!");
        return;
    }

    let table = document.getElementById("parcelTable");
    let row = table.insertRow();

    row.insertCell(0).innerText = parcelID;
    row.insertCell(1).innerText = "John Doe";
    row.insertCell(2).innerText = "Jane Smith";
    row.insertCell(3).innerText = "Processing";

    let trackingCell = row.insertCell(4);
    let trackingBar = document.createElement("progress");
    trackingBar.max = 100;
    trackingBar.value = 30;
    trackingCell.appendChild(trackingBar);
}

// 🚀 Admin Authentication
function adminLogin() {
    let userID = document.getElementById("adminUserID").value;
    let password = document.getElementById("adminPassword").value;

    if (userID === "admin" && password === "1234") {
        document.getElementById("adminSection").style.display = "block";
        alert("Admin Logged In Successfully!");
    } else {
        alert("Invalid Credentials!");
    }
}

// 🚀 Update Parcel Status (Admin)
async function updateParcel(parcelID, newStatus) {
    const token = localStorage.getItem("adminToken");
    const response = await fetch(`http://localhost:5000/api/parcels/${parcelID}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ status: newStatus })
    });

    if (response.ok) {
        alert("Parcel status updated!");
        location.reload();
    } else {
        alert("Failed to update parcel!");
    }
}