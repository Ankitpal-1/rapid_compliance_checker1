const mongoose = require("mongoose");

const parcelSchema = new mongoose.Schema({
    senderName: String,
    senderAddress: String,
    senderContact: String,
    senderEmail: String,
    receiverName: String,
    receiverAddress: String,
    receiverContact: String,
    receiverEmail: String,
    itemType: String,
    quantity: Number,
    weight: Number,
    value: Number,
    destination: String,
    customsDeclaration: String
});

const Parcel = mongoose.model("Parcel", parcelSchema);
module.exports = Parcel;
